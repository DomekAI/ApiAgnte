from fastapi import FastAPI
from routers import log, goals, memory, context, system

app = FastAPI(title="Majapi v2")

app.include_router(log.router)
app.include_router(goals.router)
app.include_router(memory.router)
app.include_router(context.router)
app.include_router(system.router)

@app.get("/")
def root():
    return {"message": "Majapi v2 is running"}
