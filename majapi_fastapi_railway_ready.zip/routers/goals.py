from fastapi import APIRouter

router = APIRouter(prefix="/goals", tags=["goals"])

@router.get("/active")
def get_active_goals():
    return {"goals": []}

@router.post("/add")
def add_goal():
    return {"message": "Goal added"}

@router.post("/link")
def link_goals():
    return {"message": "Goals linked"}

@router.get("/history")
def get_goal_history():
    return {"history": []}
