from fastapi import APIRouter

router = APIRouter(prefix="/context", tags=["context"])

@router.post("/update")
def update_context():
    return {"message": "Context updated"}

@router.get("/now")
def get_current_context():
    return {"context": {}}

@router.get("/history")
def get_context_history():
    return {"history": []}
