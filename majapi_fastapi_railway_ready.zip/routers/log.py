from fastapi import APIRouter
from models.log import DailyLog, DecisionLog
from database import db

router = APIRouter(prefix="/log", tags=["log"])

@router.post("/daily")
async def create_daily_log(entry: DailyLog):
    await db.logs_daily.insert_one(entry.dict())
    return {"message": "Daily log created"}

@router.post("/decision")
async def create_decision_log(entry: DecisionLog):
    await db.logs_decisions.insert_one(entry.dict())
    return {"message": "Decision log recorded"}

@router.get("/daily")
async def get_daily_logs():
    logs = await db.logs_daily.find().to_list(100)
    return {"logs": logs}

@router.get("/decision")
async def get_decision_logs():
    logs = await db.logs_decisions.find().to_list(100)
    return {"logs": logs}
