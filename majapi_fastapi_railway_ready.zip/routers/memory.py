from fastapi import APIRouter

router = APIRouter(prefix="/memory", tags=["memory"])

@router.post("/fact")
def add_memory_fact():
    return {"message": "Fact stored"}

@router.get("/fact")
def get_memory_fact():
    return {"facts": []}

@router.get("/map")
def get_memory_map():
    return {"map": {}}
