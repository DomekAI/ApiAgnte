from pydantic import BaseModel
from typing import List, Optional
from datetime import datetime

class Goal(BaseModel):
    goal_id: str
    title: str
    description: Optional[str]
    created_at: datetime
    status: str
    linked_goals: Optional[List[str]]
