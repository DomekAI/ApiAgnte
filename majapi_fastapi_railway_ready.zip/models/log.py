from pydantic import BaseModel
from typing import List, Optional
from datetime import datetime

class DailyLog(BaseModel):
    date: str
    mood: Optional[str]
    summary: Optional[str]
    reflections: Optional[List[str]]
    tags: Optional[List[str]]

class DecisionLog(BaseModel):
    timestamp: datetime
    source: str
    context: dict
    content: str
    impact: Optional[str]
    tags: Optional[List[str]]
    confidence: Optional[float]
