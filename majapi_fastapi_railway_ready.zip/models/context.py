from pydantic import BaseModel
from datetime import datetime
from typing import List, Optional

class ContextSnapshot(BaseModel):
    timestamp: datetime
    mode: str
    energy: Optional[str]
    focus: Optional[str]
    goal_focus: Optional[str]
    tags: Optional[List[str]]
