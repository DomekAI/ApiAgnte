from pydantic import BaseModel
from typing import List, Dict, Optional
from datetime import datetime

class SystemState(BaseModel):
    active_modules: List[str]
    current_mode: str
    last_updated: datetime
    parameters: Optional[Dict[str, str]]
