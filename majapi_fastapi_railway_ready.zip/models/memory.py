from pydantic import BaseModel
from datetime import datetime
from typing import Optional

class MemoryFact(BaseModel):
    topic: str
    fact: str
    origin: Optional[str]
    timestamp: datetime
    relevance: Optional[str]
